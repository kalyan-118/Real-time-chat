# aws-websocket-api

Contains the python code for 3 lambda handlers for a websocket chat application.